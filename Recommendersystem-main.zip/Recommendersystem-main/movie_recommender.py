import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# =========================
# 1. LOAD DATA
# =========================
movies = pd.read_csv("movies.csv")
ratings = pd.read_csv("ratings.csv")

movies['genres'] = movies['genres'].fillna('')

# =========================
# 2. CONTENT MODEL
# =========================
tfidf = TfidfVectorizer(stop_words='english')
tfidf_matrix = tfidf.fit_transform(movies['genres'])
content_similarity = cosine_similarity(tfidf_matrix)

# =========================
# 3. POPULARITY (TRENDING)
# =========================
data = ratings.merge(movies, on="movieId")

movie_stats = data.groupby('title').agg({
    'rating': ['mean', 'count']
})
movie_stats.columns = ['avg_rating', 'rating_count']

# filter only popular movies
popular_movies = movie_stats[movie_stats['rating_count'] > 50]
top_trending = popular_movies.sort_values(
    by=['avg_rating', 'rating_count'],
    ascending=False
).head(10).index.tolist()

# =========================
# 4. USER MATRIX (COLLAB FILTER)
# =========================
data = data[data['title'].isin(movie_stats.index)]

user_movie_matrix = data.pivot_table(
    index="userId",
    columns="title",
    values="rating"
)

# =========================
# 5. SMART MOVIE SEARCH
# =========================
def find_movie(name):
    name = name.lower().strip()

    matches = movies[
        movies['title'].str.lower().str.contains(name, regex=False)
    ]

    if len(matches) == 0:
        return None

    return matches.iloc[0]['title']

# =========================
# 6. CONTENT SCORE
# =========================
def content_recommend(movie):
    real_movie = find_movie(movie)
    if real_movie is None:
        return []

    idx = movies[movies['title'] == real_movie].index[0]

    scores = list(enumerate(content_similarity[idx]))
    scores = sorted(scores, key=lambda x: x[1], reverse=True)

    return [movies.iloc[i[0]].title for i in scores[1:6]]

# =========================
# 7. RATING SCORE
# =========================
def rating_recommend(movie):
    real_movie = find_movie(movie)

    if real_movie is None or real_movie not in user_movie_matrix.columns:
        return []

    movie_ratings = user_movie_matrix[real_movie]

    similar = user_movie_matrix.corrwith(movie_ratings)

    similar = similar.replace([np.inf, -np.inf], np.nan).dropna()
    similar = similar.sort_values(ascending=False)

    return list(similar.index[1:6])

# =========================
# 8. FINAL HYBRID (NETFLIX STYLE)
# =========================
def recommend(movie):
    real_movie = find_movie(movie)

    if real_movie is None:
        return top_trending

    content = content_recommend(real_movie)
    rating = rating_recommend(real_movie)

    combined = list(dict.fromkeys(content + rating))

    return combined[:5]

# =========================
# 9. DASHBOARD STYLE OUTPUT
# =========================
print("\n🎬 NETFLIX-STYLE MOVIE RECOMMENDER SYSTEM\n")
print("🔥 Trending Now:")
for t in top_trending:
    print("👉", t)

print("\n----------------------------------\n")

while True:
    movie = input("Search movie (or exit): ")

    if movie.lower() == "exit":
        break

    results = recommend(movie)

    print("\n🎯 Recommendations:")
    for r in results:
        print("👉", r)

    print("\n")